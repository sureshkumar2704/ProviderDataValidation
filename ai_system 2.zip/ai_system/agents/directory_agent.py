from typing import List, Dict, Any
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
from database.models import Provider
import json


class DirectoryAgent:
    def __init__(self):
        pass

    def export_providers(self, providers: List[Provider], fmt: str = 'json') -> str:
        data = []
        for p in providers:
            data.append({
                'provider_id': p.provider_id,
                'name': f"{p.first_name} {p.last_name}",
                'specialty': p.specialty,
                'phone': p.phone,
                'email': p.email,
                'address': p.address,
                'city': p.city,
                'state': p.state,
                'zip_code': p.zip_code,
                'facility_name': p.facility_name,
                'enriched_data': p.enriched_data,
            })

        if fmt == 'json':
            return json.dumps({'providers': data}, indent=2)
        # other formats (csv, pdf) can be added later
        return json.dumps({'providers': data})

    def generate_action_list(self, providers: List[Provider]) -> List[Dict[str, Any]]:
        actions = []
        for p in providers:
            needs = []
            if not p.phone:
                needs.append('phone')
            if not p.email:
                needs.append('email')
            if not p.address:
                needs.append('address')
            if needs:
                actions.append({'provider_id': p.provider_id, 'needs': needs})
        return actions
