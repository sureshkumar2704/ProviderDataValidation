from crewai import Agent
from langchain_core.tools import tool
from langchain_google_genai import ChatGoogleGenerativeAI
from typing import Dict, Any
import logging
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
from utils import scraper
from utils import google_maps as gmaps
from utils import confidence as conf

logger = logging.getLogger(__name__)

@tool
def enrich_specialty_info(specialty: str, certifications: str) -> str:
    """Enrich specialty information with additional context"""
    try:
        result = {
            "enriched": True,
            "data": {
                "standardized_specialty": specialty,
                "related_subspecialties": ["Subspecialty 1", "Subspecialty 2"],
                "required_certifications": ["Cert 1", "Cert 2"],
                "common_procedures": ["Procedure 1", "Procedure 2"],
                "confidence_score": 0.85
            }
        }
        return str(result)
    except Exception as e:
        logger.error(f"Specialty enrichment error: {e}")
        return str({"enriched": False, "data": None, "error": str(e)})

@tool
def suggest_services(specialty: str, current_services: str) -> str:
    """Suggest additional services based on specialty"""
    try:
        suggested_services = [
            "Telemedicine consultations",
            "Follow-up care",
            "Preventive screenings",
            "Patient education"
        ]
        result = {
            "enriched": True,
            "data": {
                "suggested_services": suggested_services,
                "specialty": specialty
            }
        }
        return str(result)
    except Exception as e:
        logger.error(f"Service suggestion error: {e}")
        return str({"enriched": False, "data": None, "error": str(e)})

@tool
def validate_certifications(certifications: str, specialty: str) -> str:
    """Validate and standardize certification information"""
    try:
        result = {
            "enriched": True,
            "data": {
                "validated_certifications": certifications,
                "standardized_names": ["MD", "Board Certified"],
                "validity_assessment": "Valid",
                "recommendations": ["Additional certification recommended"]
            }
        }
        return str(result)
    except Exception as e:
        logger.error(f"Certification validation error: {e}")
        return str({"enriched": False, "data": None, "error": str(e)})


@tool
def scrape_and_enrich(url: str, google_api_key: str = None) -> str:
    """Scrape a provider website and validate the primary address via Google Maps.

    Returns a JSON string containing phones, emails, addresses, address_validation, and confidence metrics.
    """
    try:
        scraped = scraper.scrape_website_for_provider(url)

        address = scraped.get('addresses')[0] if scraped.get('addresses') else None
        address_validation = None
        address_confidence = 0.0
        if address and google_api_key:
            address_validation = gmaps.validate_address_via_google(address, google_api_key)
            formatted = address_validation.get('formatted_address') if isinstance(address_validation, dict) else None
            address_confidence = conf.calculate_confidence(address, formatted, source_weight=1.0)

        result = {
            'scraped': scraped,
            'address_validation': address_validation,
            'address_confidence': address_confidence,
            'summary': {
                'phones_found': len(scraped.get('phones', [])),
                'emails_found': len(scraped.get('emails', [])),
                'addresses_found': len(scraped.get('addresses', [])),
            }
        }
        return json.dumps(result)
    except Exception as e:
        logger.exception('scrape_and_enrich error')
        return json.dumps({'error': str(e)})

class EnrichmentAgent:
    def __init__(self, gemini_api_key: str):
        self.llm = ChatGoogleGenerativeAI(
            model="gemini-pro",
            temperature=0.3,
            google_api_key=gemini_api_key
        )

    def create_agent(self) -> Agent:
        return Agent(
            role="Healthcare Data Enricher",
            goal="Enrich healthcare provider data with additional relevant information",
            backstory="""You are a specialist in healthcare data enrichment, skilled at
            identifying gaps in provider information and suggesting improvements based
            on industry standards and best practices.""",
            llm=self.llm,
            tools=[enrich_specialty_info, suggest_services, validate_certifications, scrape_and_enrich],
            verbose=True
        )