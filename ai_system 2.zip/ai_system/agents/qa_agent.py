from typing import Dict, Any
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
from utils import confidence
import logging

logger = logging.getLogger(__name__)


class QAAgent:
    """Quality Assurance Agent: compares provider local data with external enrichment
    and produces flags and confidence metrics.
    """
    def __init__(self):
        pass

    def analyze(self, local: Dict[str, Any], enrichment: Dict[str, Any]) -> Dict[str, Any]:
        flags = {}
        confidences = {}

        # Address comparison
        ext_addr = None
        if enrichment:
            addr_val = enrichment.get('address_validation') or enrichment.get('scraped') or {}
            if isinstance(addr_val, dict):
                ext_addr = addr_val.get('formatted_address') or (addr_val.get('scraped', {}).get('addresses', [None])[0] if addr_val.get('scraped') else None)

        addr_conf = confidence.calculate_confidence(local.get('address'), ext_addr, source_weight=1.0)
        confidences['address'] = addr_conf
        if addr_conf < 0.5:
            flags['address'] = {'local': local.get('address'), 'external': ext_addr}

        # Phone / email presence
        scraped = enrichment.get('scraped') if enrichment else {}
        phones = scraped.get('phones', []) if isinstance(scraped, dict) else []
        emails = scraped.get('emails', []) if isinstance(scraped, dict) else []
        confidences['phone_count'] = len(phones)
        confidences['email_count'] = len(emails)
        if not phones:
            flags['phone_missing'] = True
        if not emails:
            flags['email_missing'] = True

        score = confidence.aggregate_confidences([v for v in confidences.values() if isinstance(v, (int, float))])

        return {
            'flags': flags,
            'confidences': confidences,
            'overall_score': score
        }
