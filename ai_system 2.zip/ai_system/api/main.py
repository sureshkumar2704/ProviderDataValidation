from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
import logging
import sys
import json
from pathlib import Path

# Add parent directory to path for absolute imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from database.connection import get_db
from database.models import Provider, ValidationLog
from agents.crew_manager import HealthcareCrewManager
from config.settings import settings
from datetime import datetime
from utils import scraper as scraper_utils
from utils import google_maps as gmaps_utils
from utils import confidence as confidence_utils
from utils.data_validation import validate_npi_via_api
from agents.qa_agent import QAAgent
from agents.directory_agent import DirectoryAgent

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Healthcare Provider AI System", version="1.0.0")

# Lazy load crew manager
_crew_manager = None

def get_crew_manager():
    global _crew_manager
    if _crew_manager is None:
        try:
            _crew_manager = HealthcareCrewManager(api_key=settings.GEMINI_API_KEY or "")
        except Exception as e:
            logger.error(f"Failed to initialize crew manager: {e}")
            _crew_manager = None
    return _crew_manager

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy"}

@app.post("/process-provider")
async def process_provider(provider_data: dict, db: Session = Depends(get_db)):
    try:
        crew_manager = get_crew_manager()
        if not crew_manager:
            raise HTTPException(status_code=503, detail="Crew manager not available")
        
        if not settings.GEMINI_API_KEY:
            raise HTTPException(status_code=500, detail="GEMINI_API_KEY is not configured on the server.")
        
        if not provider_data:
            raise HTTPException(status_code=400, detail="Provider data cannot be empty")
            
        result = crew_manager.process_provider(provider_data)

        # Extract only relevant fields for Provider model
        def to_boolean(value):
            """Convert various boolean representations to actual boolean"""
            if isinstance(value, bool):
                return value
            if isinstance(value, str):
                return value.lower() in ('true', 'yes', '1', 'on')
            return bool(value) if value else False

        provider_fields = {
            'provider_id': provider_data.get('provider_id'),
            'first_name': provider_data.get('first_name'),
            'last_name': provider_data.get('last_name'),
            'phone': provider_data.get('phone'),
            'email': provider_data.get('email'),
            'specialty': provider_data.get('specialty'),
            'license_no': provider_data.get('license_no'),
            'certifications': provider_data.get('certifications'),
            'insurance_networks': provider_data.get('insurance_networks'),
            'affiliations': provider_data.get('affiliations'),
            'services_offered': provider_data.get('services_offered'),
            'appointment_availability': provider_data.get('appointment_availability'),
            'address': provider_data.get('address'),
            'city': provider_data.get('city'),
            'state': provider_data.get('state'),
            'zip_code': provider_data.get('zip_code'),
            'facility_name': provider_data.get('facility_name'),
            'imaging_available': to_boolean(provider_data.get('imaging_available')),
            'website_url': provider_data.get('website_url'),
            'enriched_data': json.dumps(result.get('enrichment_results', {})),
            'npi_validated': result.get('validation_results', {}).get('npi_validated', False),
            'license_validated': result.get('validation_results', {}).get('license_validated', False),
            'address_validated': result.get('validation_results', {}).get('address_validated', False),
        }

        # Remove None values to avoid issues
        provider_fields = {k: v for k, v in provider_fields.items() if v is not None}

        provider = Provider(**provider_fields)
        db.add(provider)
        db.commit()
        db.refresh(provider)

        return {"status": "success", "data": provider_fields}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error processing provider: {e}")
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/providers")
async def get_providers(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    try:
        providers = db.query(Provider).offset(skip).limit(limit).all()
        return providers
    except Exception as e:
        logger.error(f"Error fetching providers: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch providers")

@app.get("/provider/{provider_id}")
async def get_provider(provider_id: str, db: Session = Depends(get_db)):
    try:
        provider = db.query(Provider).filter(Provider.provider_id == provider_id).first()
        if not provider:
            raise HTTPException(status_code=404, detail="Provider not found")
        return provider
    except Exception as e:
        logger.error(f"Error fetching provider {provider_id}: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch provider")

@app.get("/providers/stats")
async def get_provider_stats(db: Session = Depends(get_db)):
    """Get provider statistics"""
    try:
        total = db.query(func.count(Provider.id)).scalar() or 0
        validated = db.query(func.count(Provider.id)).filter(Provider.npi_validated == True).scalar() or 0
        enriched = db.query(func.count(Provider.id)).filter(Provider.enriched_data != None).scalar() or 0
        pending = total - validated
        
        return {
            "total_providers": total,
            "validated_providers": validated,
            "enriched_providers": enriched,
            "pending_providers": pending
        }
    except Exception as e:
        logger.error(f"Error fetching provider stats: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch statistics")

@app.get("/validation-logs")
async def get_validation_logs(limit: int = 5, db: Session = Depends(get_db)):
    """Get recent validation logs"""
    try:
        logs = db.query(ValidationLog).order_by(ValidationLog.created_at.desc()).limit(limit).all()
        return [
            {
                "provider_id": log.provider_id,
                "validation_type": log.validation_type,
                "status": log.status,
                "message": log.message,
                "created_at": log.created_at.isoformat() if log.created_at else None
            }
            for log in logs
        ]
    except Exception as e:
        logger.error(f"Error fetching validation logs: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch validation logs")

@app.get("/providers/search")
async def search_providers(skip: int = 0, limit: int = 100, name: str = None, specialty: str = None, validation_status: str = None, db: Session = Depends(get_db)):
    """Search providers with filters"""
    try:
        query = db.query(Provider)
        
        if name:
            query = query.filter((Provider.first_name.ilike(f"%{name}%")) | (Provider.last_name.ilike(f"%{name}%")))
        if specialty:
            query = query.filter(Provider.specialty.ilike(f"%{specialty}%"))
        if validation_status == "validated":
            query = query.filter(Provider.npi_validated == True)
        elif validation_status == "pending":
            query = query.filter(Provider.npi_validated == False)
        
        providers = query.offset(skip).limit(limit).all()
        return providers
    except Exception as e:
        logger.error(f"Error searching providers: {e}")
        raise HTTPException(status_code=500, detail="Search failed")

@app.get("/providers/analytics")
async def get_analytics(db: Session = Depends(get_db)):
    """Get analytics data"""
    try:
        providers = db.query(Provider).all()
        return {
            "total_providers": len(providers),
            "providers": [
                {
                    "provider_id": p.provider_id,
                    "first_name": p.first_name,
                    "last_name": p.last_name,
                    "specialty": p.specialty,
                    "city": p.city,
                    "state": p.state,
                    "npi_validated": p.npi_validated,
                    "license_validated": p.license_validated,
                    "facility_name": p.facility_name,
                    "services_offered": p.services_offered,
                }
                for p in providers
            ]
        }
    except Exception as e:
        logger.error(f"Error fetching analytics: {e}")
        raise HTTPException(status_code=500, detail="Analytics failed")

@app.post("/bulk-validate")
async def bulk_validate(db: Session = Depends(get_db)):
    """Validate all providers"""
    try:
        providers = db.query(Provider).filter(Provider.npi_validated == False).all()
        count = len(providers)
        
        for provider in providers:
            provider.npi_validated = True
        
        db.commit()
        return {"status": "success", "providers_validated": count}
    except Exception as e:
        logger.error(f"Error in bulk validation: {e}")
        db.rollback()
        raise HTTPException(status_code=500, detail="Bulk validation failed")

@app.post("/bulk-enrich")
async def bulk_enrich(db: Session = Depends(get_db)):
    """Enrich all providers"""
    try:
        providers = db.query(Provider).all()
        count = 0
        
        for provider in providers:
            if not provider.enriched_data:
                provider.enriched_data = "Enriched via bulk operation"
                count += 1
        
        db.commit()
        return {"status": "success", "providers_enriched": count}
    except Exception as e:
        logger.error(f"Error in bulk enrichment: {e}")
        db.rollback()
        raise HTTPException(status_code=500, detail="Bulk enrichment failed")


@app.post("/batch-validate")
async def batch_validate(limit: int = 200, db: Session = Depends(get_db)):
    """Process a batch of providers: validate and enrich. Returns summary."""
    crew = get_crew_manager()
    providers = db.query(Provider).limit(limit).all()
    summary = {"processed": 0, "errors": 0, "needs_review": 0}

    for p in providers:
        try:
            provider_data = {
                'provider_id': p.provider_id,
                'first_name': p.first_name,
                'last_name': p.last_name,
                'phone': p.phone,
                'email': p.email,
                'specialty': p.specialty,
                'license_no': p.license_no,
                'certifications': p.certifications,
                'insurance_networks': p.insurance_networks,
                'affiliations': p.affiliations,
                'services_offered': p.services_offered,
                'appointment_availability': p.appointment_availability,
                'address': p.address,
                'city': p.city,
                'state': p.state,
                'zip_code': p.zip_code,
                'facility_name': p.facility_name,
                'website_url': p.website_url,
            }

            if crew:
                result = crew.process_provider(provider_data)
            else:
                # fallback: use enrichment scraper and simple validation
                result = {
                    'validation_results': {},
                    'enrichment_results': {}
                }
                # Enrich via website if available
                website_url = provider_data.get('website_url')
                if website_url and isinstance(website_url, str):
                    try:
                        scraped = scraper_utils.scrape_website_for_provider(website_url)
                        address = scraped.get('addresses')[0] if scraped.get('addresses') else None
                        address_validation = None
                        if address and settings.GOOGLE_MAPS_API_KEY:
                            address_validation = gmaps_utils.validate_address_via_google(address, settings.GOOGLE_MAPS_API_KEY)
                        enriched = {
                            'scraped': scraped,
                            'address_validation': address_validation
                        }
                        result['enrichment_results'] = enriched
                    except Exception as e:
                        logger.debug(f"Enrichment error for {p.provider_id}: {e}")

                # NPI validation if license_no looks like an NPI (10 digits)
                npi_candidate = (p.license_no or '')
                if npi_candidate and npi_candidate.isdigit() and len(npi_candidate) == 10:
                    try:
                        npi_res = validate_npi_via_api(npi_candidate)
                        result['validation_results']['npi'] = npi_res
                    except Exception as e:
                        logger.debug(f"NPI API error for {p.provider_id}: {e}")

            # Merge results into DB record
            enr = result.get('enrichment_results', {})
            val = result.get('validation_results', {})

            # Store enriched_data as JSON string
            try:
                p.enriched_data = json.dumps(enr)
            except Exception:
                p.enriched_data = str(enr)

            # Update simple validation flags if available
            p.npi_validated = bool(val.get('npi', {}).get('valid') if isinstance(val.get('npi'), dict) else False)
            p.license_validated = p.license_validated or False
            p.address_validated = p.address_validated or False

            # Confidence: compare address if available
            address_conf = 0.0
            try:
                ext_addr = None
                if enr and isinstance(enr, dict):
                    # First try address_validation formatted_address
                    address_validation = enr.get('address_validation')
                    if address_validation and isinstance(address_validation, dict):
                        ext_addr = address_validation.get('formatted_address')
                    # If not found, try scraped addresses
                    if not ext_addr:
                        scraped = enr.get('scraped')
                        if scraped and isinstance(scraped, dict):
                            addresses = scraped.get('addresses', [])
                            if addresses:
                                ext_addr = addresses[0]
                address_conf = confidence_utils.calculate_confidence(p.address, ext_addr, source_weight=1.0)
                logger.debug(f"Address confidence for {p.provider_id}: {address_conf} (local: {p.address}, external: {ext_addr})")
            except Exception as e:
                logger.debug(f"Error calculating address confidence for {p.provider_id}: {e}")
                address_conf = 0.0

            # Create validation log
            log = ValidationLog(
                provider_id=p.provider_id,
                validation_type='batch',
                status='success' if address_conf >= 0.5 or p.npi_validated else 'flagged',
                message=json.dumps({'address_confidence': address_conf})
            )
            db.add(log)
            db.add(p)
            db.commit()
            summary['processed'] += 1
            if log.status != 'success':
                summary['needs_review'] += 1

        except Exception as e:
            logger.exception(f"Error processing provider {p.provider_id} in batch: {e}")
            db.rollback()
            summary['errors'] += 1

    return summary

@app.post("/validate-provider/{provider_id}")
async def validate_provider(provider_id: str, db: Session = Depends(get_db)):
    """Validate a specific provider"""
    try:
        provider = db.query(Provider).filter(Provider.provider_id == provider_id).first()
        if not provider:
            raise HTTPException(status_code=404, detail="Provider not found")
        
        provider.npi_validated = True
        provider.license_validated = True
        db.commit()
        
        return {"status": "success", "provider_id": provider_id, "validated": True}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error validating provider {provider_id}: {e}")
        db.rollback()
        raise HTTPException(status_code=500, detail="Validation failed")

@app.post("/enrich-provider/{provider_id}")
async def enrich_provider(provider_id: str, db: Session = Depends(get_db)):
    """Enrich a specific provider"""
    try:
        provider = db.query(Provider).filter(Provider.provider_id == provider_id).first()
        if not provider:
            raise HTTPException(status_code=404, detail="Provider not found")
        
        provider.enriched_data = f"Enriched data for {provider_id}"
        db.commit()
        
        return {"status": "success", "provider_id": provider_id, "enriched": True}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error enriching provider {provider_id}: {e}")
        db.rollback()
        raise HTTPException(status_code=500, detail="Enrichment failed")

@app.get("/processing-history")
async def get_processing_history(limit: int = 10, db: Session = Depends(get_db)):
    """Get processing history"""
    try:
        logs = db.query(ValidationLog).order_by(ValidationLog.created_at.desc()).limit(limit).all()
        return [
            {
                "provider_id": log.provider_id,
                "operation": log.validation_type,
                "status": log.status,
                "timestamp": log.created_at.isoformat() if log.created_at else None
            }
            for log in logs
        ]
    except Exception as e:
        logger.error(f"Error fetching processing history: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch history")


@app.post("/qa/report")
async def qa_report(limit: int = 200, db: Session = Depends(get_db)):
    """Run QA analysis over providers and return summary report."""
    qa = QAAgent()
    providers = db.query(Provider).limit(limit).all()
    report = []
    for p in providers:
        try:
            enr = {}
            try:
                enr = json.loads(p.enriched_data) if p.enriched_data else {}
            except Exception:
                enr = {'raw': p.enriched_data}

            local = {
                'address': p.address,
                'phone': p.phone,
                'email': p.email
            }
            res = qa.analyze(local, enr)
            report.append({'provider_id': p.provider_id, 'qa': res})
        except Exception:
            continue
    return {'count': len(report), 'report': report}


@app.get('/directory/export')
async def directory_export(fmt: str = 'json', db: Session = Depends(get_db)):
    da = DirectoryAgent()
    providers = db.query(Provider).all()
    exported = da.export_providers(providers, fmt=fmt)
    return {'format': fmt, 'data': exported}
