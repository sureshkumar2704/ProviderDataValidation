import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    # OpenAI API
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY") # Kept for compatibility if needed
    GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
    # Database
    DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./healthcare.db")

    # API Keys for external services
    NPI_API_KEY = os.getenv("NPI_API_KEY")
    GOOGLE_MAPS_API_KEY = os.getenv("GOOGLE_MAPS_API_KEY")

    # Application settings
    APP_NAME = "Healthcare Provider AI System"
    DEBUG = os.getenv("DEBUG", "False").lower() == "true"

settings = Settings()
