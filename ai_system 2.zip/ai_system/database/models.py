from sqlalchemy import Column, Integer, String, Text, Boolean, DateTime, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import func

Base = declarative_base()

class Provider(Base):
    __tablename__ = "providers"

    id = Column(Integer, primary_key=True, index=True)
    provider_id = Column(String, unique=True, index=True)
    first_name = Column(String)
    last_name = Column(String)
    phone = Column(String)
    email = Column(String)
    specialty = Column(String)
    license_no = Column(String)
    certifications = Column(Text)
    insurance_networks = Column(Text)
    affiliations = Column(Text)
    services_offered = Column(Text)
    appointment_availability = Column(String)
    address = Column(String)
    city = Column(String)
    state = Column(String)
    zip_code = Column(String)
    facility_name = Column(String)
    imaging_available = Column(Boolean)
    website_url = Column(String)

    # Validation and enrichment fields
    npi_validated = Column(Boolean, default=False)
    license_validated = Column(Boolean, default=False)
    address_validated = Column(Boolean, default=False)
    enriched_data = Column(Text)
    validation_score = Column(Float, default=0.0)
    last_updated = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

class ValidationLog(Base):
    __tablename__ = "validation_logs"

    id = Column(Integer, primary_key=True, index=True)
    provider_id = Column(String, index=True)
    validation_type = Column(String)  # npi, license, address
    status = Column(String)  # success, failed, pending
    message = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
