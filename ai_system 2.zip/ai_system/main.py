import subprocess
import time
import os
import sys
from pathlib import Path

# Add the project root to Python path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from database.connection import engine
from database.models import Base
from utils.data_loader import load_provider_data
from config.settings import settings

def init_database():
    """Initialize database tables"""
    Base.metadata.create_all(bind=engine)
    print("Database initialized")

def load_initial_data():
    """Load initial provider data from CSV"""
    # The path should be relative to the project root directory where this script is run.
    csv_path = "Round_2/provider_dataset_300.csv"
    if os.path.exists(csv_path):
        providers = load_provider_data(csv_path)
        print(f"Loaded {len(providers)} providers from CSV")
        # TODO: In a real application, you would insert 'providers' into the database here.
    else:
        print(f"Warning: Initial data file not found at '{csv_path}', skipping data load.")

def run_api():
    """Run FastAPI server"""
    subprocess.run(["python3", "-m", "uvicorn", "api.main:app", "--host", "0.0.0.0", "--port", "8000", "--reload"])

def run_ui():
    """Run Streamlit UI"""
    subprocess.run(["streamlit", "run", "ui/app.py", "--server.port", "8501", "--server.address", "0.0.0.0"])

if __name__ == "__main__":
    init_database()
    load_initial_data()

    # Get the project root directory to set the PYTHONPATH
    project_root = os.getcwd()
    env = os.environ.copy()
    env["PYTHONPATH"] = project_root + os.pathsep + env.get("PYTHONPATH", "")

    # Run API in a separate process
    # Use python -m uvicorn to ensure proper module resolution
    api_command = ["python3", "-m", "uvicorn", "api.main:app", "--host", "0.0.0.0", "--port", "8000", "--reload"]
    api_process = subprocess.Popen(api_command, cwd=project_root, env=env)

    # Give API time to start
    print("Waiting for API server to start...")
    time.sleep(5) # Increased sleep time slightly for more stability

    try:
        print("Starting Streamlit UI...")
        streamlit_command = ["streamlit", "run", "ui/app.py", "--server.port", "8501", "--server.address", "0.0.0.0"]
        # Run UI in the main process. This will block until the Streamlit app is closed.
        subprocess.run(streamlit_command, cwd=project_root, env=env)
    finally:
        print("Shutting down API server...")
        api_process.terminate()
        api_process.wait()
