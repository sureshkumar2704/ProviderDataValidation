import streamlit as st
import pandas as pd
import requests
import json
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import time
from datetime import datetime
import os
import sys
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from utils.data_loader import load_provider_data

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        font-size: 3rem;
        font-weight: bold;
        background: linear-gradient(45deg, #1e3c72, #2a5298);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-align: center;
        margin-bottom: 2rem;
    }
    .metric-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 1rem;
        border-radius: 10px;
        color: white;
        text-align: center;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    .success-card {
        background: linear-gradient(135deg, #4CAF50, #45a049);
        padding: 1rem;
        border-radius: 10px;
        color: white;
        text-align: center;
    }
    .warning-card {
        background: linear-gradient(135deg, #FF9800, #F57C00);
        padding: 1rem;
        border-radius: 10px;
        color: white;
        text-align: center;
    }
    .stTabs [data-baseweb="tab-list"] {
        gap: 2px;
    }
    .stTabs [data-baseweb="tab"] {
        height: 50px;
        white-space: pre-wrap;
        background-color: #f0f2f6;
        border-radius: 4px 4px 0 0;
        gap: 1px;
        padding-top: 10px;
        padding-bottom: 10px;
    }
    .stTabs [aria-selected="true"] {
        background-color: #1f77b4;
        color: white;
    }
</style>
""", unsafe_allow_html=True)

st.set_page_config(
    page_title="Healthcare Provider AI System",
    page_icon="🏥",
    layout="wide",
    initial_sidebar_state="expanded"
)

API_BASE_URL = "http://localhost:8000"

# --- Helper function for API requests ---
@st.cache_data(ttl=60) # Cache data for 60 seconds to reduce API calls
def api_request(method: str, endpoint: str, **kwargs):
    """
    Makes a request to the API, handles connection errors, and caches the response.
    Returns the JSON response on success, None on failure.
    """
    try:
        url = f"{API_BASE_URL}/{endpoint}"
        response = requests.request(method, url, timeout=15, **kwargs)
        response.raise_for_status()  # Raise an exception for 4xx or 5xx status codes
        return response.json()
    except requests.exceptions.RequestException as e:
        # This will be triggered by connection errors, timeouts, or bad status codes.
        # We'll show a single, persistent warning at the top of the app.
        st.session_state.api_offline = True
        st.session_state.api_error_message = str(e)
        return None

if 'api_offline' not in st.session_state:
    st.session_state.api_offline = False

# Sidebar
with st.sidebar:
    st.image("https://img.icons8.com/fluency/96/000000/hospital.png", width=80)
    st.title("🏥 Healthcare AI Dashboard")

    st.markdown("---")
    st.markdown("### Quick Stats")

    stats = api_request("get", "providers/stats")
    if stats:
        st.metric("Total Providers", stats.get('total_providers', 0))
        st.metric("Validated", stats.get('validated_providers', 0))
        st.metric("Pending Review", stats.get('pending_providers', 0))
    else:
        st.metric("Total Providers", "Offline")

    st.markdown("---")
    st.markdown("### Navigation")
    page = st.radio("Go to", ["Dashboard", "Data Management", "Provider Search", "Analytics", "AI Processing"])

# Main content

# Display a persistent warning if the API is offline
if st.session_state.api_offline:
    st.warning(f"🚨 API is offline or unreachable. Please ensure the backend server is running. Error: {st.session_state.api_error_message}", icon="⚠️")

if page == "Dashboard":
    st.markdown('<h1 class="main-header">🏥 Healthcare Provider AI System</h1>', unsafe_allow_html=True)

    # Get basic stats from providers endpoint
    providers = api_request("get", "providers", params={"limit": 1000})
    if providers and isinstance(providers, list):
        total_providers = len(providers)

        # Calculate basic metrics
        validated_count = sum(1 for p in providers if p.get('npi_validated') or p.get('license_validated'))
        enriched_count = sum(1 for p in providers if p.get('enriched_data'))

        col1, col2, col3, col4 = st.columns(4)

        with col1:
            st.markdown(f"""
            <div class="metric-card">
                <h3>{total_providers}</h3>
                <p>Total Providers</p>
            </div>
            """, unsafe_allow_html=True)

        with col2:
            validated_pct = (validated_count / max(total_providers, 1)) * 100
            st.markdown(f"""
            <div class="success-card">
                <h3>{validated_count}</h3>
                <p>Validated ({validated_pct:.1f}%)</p>
            </div>
            """, unsafe_allow_html=True)

        with col3:
            pending = total_providers - validated_count
            st.markdown(f"""
            <div class="warning-card">
                <h3>{pending}</h3>
                <p>Pending Review</p>
            </div>
            """, unsafe_allow_html=True)

        with col4:
            st.markdown(f"""
            <div class="metric-card">
                <h3>{enriched_count}</h3>
                <p>AI Enriched</p>
            </div>
            """, unsafe_allow_html=True)
    else:
        st.info("Dashboard metrics are unavailable because the API is offline.")

    # Recent Activity
    st.markdown("### 📊 Recent Activity")
    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Latest Validations")
        logs = api_request("get", "validation-logs", params={"limit": 5})
        if logs:
            for log in logs:
                status_icon = "✅" if log.get('status') == 'success' else "❌"
                st.write(f"{status_icon} {log.get('provider_id')} - {log.get('validation_type')}")
        else:
            st.info("Validation logs unavailable")

    with col2:
        st.subheader("System Health")
        # Check API health
        health = api_request("get", "health")
        if health:
            st.success("✅ API Service: Online")
        else:
            st.error("❌ API Service: Offline")

        # Database check
        db_check = api_request("get", "providers", params={"limit": 1})
        if db_check is not None: # Check for not None, as an empty list is a valid response
            st.success("✅ Database: Connected")
        else:
            st.warning("⚠️ Database: Offline")

elif page == "Data Management":
    st.header("📁 Data Management")

    tab1, tab2 = st.tabs(["Upload Data", "Bulk Processing"])

    with tab1:
        st.subheader("Upload Provider Data")
        uploaded_file = st.file_uploader("Choose CSV file", type="csv", help="Upload a CSV file with healthcare provider data")

        if uploaded_file is not None:
            df = pd.read_csv(uploaded_file)
            st.success(f"📊 File loaded successfully! {len(df)} records found.")

            # Data preview
            with st.expander("Preview Data", expanded=True):
                st.dataframe(df.head(10), use_container_width=True)

            # Data quality check
            st.subheader("Data Quality Check")
            col1, col2, col3 = st.columns(3)

            with col1:
                missing_data = df.isnull().sum().sum()
                st.metric("Missing Values", missing_data)

            with col2:
                duplicate_ids = df['provider_id'].duplicated().sum()
                st.metric("Duplicate IDs", duplicate_ids)

            with col3:
                complete_records = len(df.dropna())
                st.metric("Complete Records", f"{complete_records}/{len(df)}")

            if st.button("🚀 Process & Upload Data", type="primary"):
                with st.spinner("Processing providers with AI agents..."):
                    uploaded_file.seek(0)
                    df = pd.read_csv(uploaded_file)
                    providers = df.to_dict('records')

                    progress_bar = st.progress(0)
                    status_text = st.empty()
                    success_count = 0
                    error_count = 0

                    for i, provider in enumerate(providers):
                        try:
                            # Using a non-cached function for POST requests
                            response = requests.post(f"{API_BASE_URL}/process-provider", json=provider, timeout=30)
                            if response.ok:
                                success_count += 1
                                status_text.text(f"✅ Processed {success_count}/{len(providers)} providers")
                            else:
                                error_count += 1
                                st.error(f"❌ Error processing provider {provider['provider_id']}: {response.text}")
                        except requests.exceptions.RequestException as e:
                            error_count += 1
                            st.error(f"❌ Network error processing provider {provider['provider_id']}: {e}")


                        progress_bar.progress((i + 1) / len(providers))

                    if success_count > 0:
                        st.success(f"🎉 Successfully processed {success_count} providers!")
                    if error_count > 0:
                        st.warning(f"⚠️ {error_count} providers had errors during processing.")

    with tab2:
        st.subheader("Bulk AI Processing")
        st.markdown("Process existing providers with AI validation and enrichment")

        col1, col2 = st.columns(2)

        with col1:
            if st.button("🔄 Re-validate All Providers", type="primary"):
                with st.spinner("Re-validating all providers..."):
                    response = api_request("post", "batch-validate")
                    if response:
                        st.success("✅ Bulk validation initiated successfully!")
                        st.json(response)
                    else:
                        st.error("❌ Failed to initiate bulk validation. Is the API running?")

        with col2:
            st.info("Enrichment is handled automatically during batch validation.")

elif page == "Provider Search":
    st.header("🔍 Provider Search & Management")

    # Search filters
    col1, col2, col3 = st.columns(3)

    with col1:
        search_name = st.text_input("Search by Name", placeholder="Enter provider name...")

    with col2:
        search_specialty = st.selectbox("Filter by Specialty",
            ["All"] + ["Cardiology", "Dermatology", "Neurology", "Oncology", "Pediatrics", "Radiology", "Surgery"])

    with col3:
        validation_status = st.selectbox("Validation Status", ["All", "Validated", "Pending", "Failed"])

    # Search button
    if st.button("🔍 Search Providers", type="primary"):
        with st.spinner("Searching providers..."):
            params = {"limit": 100}
            if search_name:
                params["name"] = search_name
            if search_specialty != "All":
                params["specialty"] = search_specialty
            if validation_status != "All":
                params["validation_status"] = validation_status.lower()

            providers = api_request("get", "providers/search", params=params)

            if providers is not None:
                if providers:
                    st.success(f"Found {len(providers)} providers")

                    # Display results in a nice table
                    df = pd.DataFrame(providers)
                    display_cols = ['provider_id', 'first_name', 'last_name', 'specialty', 'city', 'state', 'npi_validated', 'license_validated']
                    available_cols = [col for col in display_cols if col in df.columns]

                    st.dataframe(df[available_cols], use_container_width=True)

                    # Export option
                    csv = df.to_csv(index=False)
                    st.download_button(
                        label="📥 Download Results as CSV",
                        data=csv,
                        file_name="provider_search_results.csv",
                        mime="text/csv"
                    )
                else:
                    st.info("No providers found matching your criteria")
            else:
                st.error("Search failed. Is the API running?")

    # Provider details section
    st.markdown("---")
    st.subheader("Provider Details")

    provider_id = st.text_input("Enter Provider ID for detailed view", placeholder="e.g., P001")
    if st.button("Get Provider Details"):
        if provider_id:
            with st.spinner("Fetching provider details..."):
                # Get all providers and find the specific one
                all_providers = api_request("get", "providers", params={"limit": 1000})
                provider = None
                if all_providers and isinstance(all_providers, list):
                    provider = next((p for p in all_providers if p.get('provider_id') == provider_id), None)
                if provider:

                        # Display in organized cards
                        col1, col2 = st.columns(2)

                        with col1:
                            st.markdown("### 👤 Basic Information")
                            st.write(f"**Name:** {provider.get('first_name', 'N/A')} {provider.get('last_name', 'N/A')}")
                            st.write(f"**Specialty:** {provider.get('specialty', 'N/A')}")
                            st.write(f"**Phone:** {provider.get('phone', 'N/A')}")
                            st.write(f"**Email:** {provider.get('email', 'N/A')}")

                        with col2:
                            st.markdown("### 📍 Location & Contact")
                            st.write(f"**Address:** {provider.get('address', 'N/A')}")
                            st.write(f"**City:** {provider.get('city', 'N/A')}, {provider.get('state', 'N/A')} {provider.get('zip_code', 'N/A')}")
                            st.write(f"**Facility:** {provider.get('facility_name', 'N/A')}")
                            st.write(f"**Website:** {provider.get('website_url', 'N/A')}")

                        # Validation status
                        st.markdown("### ✅ Validation Status")
                        val_col1, val_col2, val_col3 = st.columns(3)

                        npi_status = "✅ Validated" if provider.get('npi_validated') else "⏳ Pending"
                        license_status = "✅ Validated" if provider.get('license_validated') else "⏳ Pending"
                        address_status = "✅ Validated" if provider.get('address_validated') else "⏳ Pending"

                        with val_col1:
                            st.metric("NPI Status", npi_status)
                        with val_col2:
                            st.metric("License Status", license_status)
                        with val_col3:
                            st.metric("Address Status", address_status)

                        # AI Enrichment results
                        if provider.get('enriched_data'):
                            st.markdown("### 🤖 AI Enrichment")
                            # Try to parse enriched_data if it's a JSON string
                            try:
                                enriched = provider['enriched_data']
                                if isinstance(enriched, str):
                                    enriched_parsed = json.loads(enriched)
                                else:
                                    enriched_parsed = enriched
                            except Exception:
                                enriched_parsed = provider['enriched_data']
                            st.json(enriched_parsed)

                        # QA / Confidence (on-demand)
                        st.markdown("### 🧾 QA & Confidence")
                        if st.button("Run QA for this provider"):
                            with st.spinner("Running QA..."):
                                qa_resp = api_request("post", "qa/report")
                                if qa_resp and qa_resp.get('report'):
                                    entry = next((r for r in qa_resp['report'] if r.get('provider_id') == provider.get('provider_id')), None)
                                    if entry:
                                        st.json(entry.get('qa'))
                                        # Show quick summary if present
                                        qa_data = entry.get('qa') or {}
                                        if isinstance(qa_data, dict):
                                            score = qa_data.get('overall_score') or qa_data.get('score') or provider.get('validation_score')
                                            st.write(f"**Overall QA Score:** {score}")
                                    else:
                                        st.info("No QA entry found for this provider in the latest report.")
                                else:
                                    st.error("QA report generation failed or API offline.")
                else:
                    st.error(f"Could not find or fetch provider '{provider_id}'. Please check the ID and API status.")

        else:
            st.warning("Please enter a Provider ID")

elif page == "Analytics":
    st.header("📊 Analytics Dashboard")
    
    # Add a quick stats row at the top
    try:
        stats = api_request("get", "providers/stats")
        if stats:
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Total Providers", stats.get('total_providers', 0))
            with col2:
                st.metric("Validated", stats.get('validated_providers', 0))
            with col3:
                st.metric("Enriched", stats.get('enriched_providers', 0))
            with col4:
                st.metric("Pending", stats.get('pending_providers', 0))
    except:
        pass

    try:
        # Get providers data for analytics
        providers = api_request("get", "providers", params={"limit": 1000})
        if providers and isinstance(providers, list):
            df = pd.DataFrame(providers)
            if not df.empty:
                # ========== MAIN VISUALIZATION SECTION ==========
                st.markdown("---")
                st.markdown("## 📈 Interactive Visualizations")
                
                # Create tabs for different visualization categories
                viz_tab1, viz_tab2, viz_tab3, viz_tab4 = st.tabs(["📍 Geographic", "✅ Validation", "📊 Overview", "🔍 Detailed Analysis"])
                
                with viz_tab1:
                    # GEOGRAPHIC VISUALIZATIONS
                    st.subheader("🌍 Geographic Distribution")
                    
                    if 'state' in df.columns:
                        state_data = df['state'].dropna()
                        state_data = state_data[state_data != '']
                        
                        if len(state_data) > 0:
                            state_counts = state_data.value_counts()
                            
                            # Row 1: State bar chart and pie chart
                            col1, col2 = st.columns([2, 1])
                            
                            with col1:
                                fig_state_bar = px.bar(
                                    x=state_counts.index,
                                    y=state_counts.values,
                                    title="📊 Providers by State - Bar Chart",
                                    labels={'x': 'State', 'y': 'Number of Providers'},
                                    color=state_counts.values,
                                    color_continuous_scale="Blues",
                                    text=state_counts.values
                                )
                                fig_state_bar.update_traces(texttemplate='%{text}', textposition='outside')
                                fig_state_bar.update_layout(showlegend=False, height=400)
                                st.plotly_chart(fig_state_bar, use_container_width=True)
                            
                            with col2:
                                fig_state_pie = px.pie(
                                    values=state_counts.values,
                                    names=state_counts.index,
                                    title="🥧 State Distribution",
                                    hole=0.3
                                )
                                fig_state_pie.update_traces(textposition='inside', textinfo='percent+label')
                                st.plotly_chart(fig_state_pie, use_container_width=True)
                            
                            # Row 2: Choropleth map
                            try:
                                fig_map = px.choropleth(
                                    locations=state_counts.index,
                                    locationmode="USA-states",
                                    color=state_counts.values,
                                    scope="usa",
                                    title="🗺️ Geographic Distribution Map - USA",
                                    color_continuous_scale="Blues",
                                    labels={'color': 'Number of Providers'}
                                )
                                fig_map.update_layout(height=500)
                                st.plotly_chart(fig_map, use_container_width=True)
                            except Exception as e:
                                st.warning(f"Map visualization: {str(e)}")
                                # Fallback: show state data table
                                st.dataframe(state_counts.reset_index().rename(columns={'index': 'State', 'state': 'Count'}))
                    
                    # City visualizations
                    if 'city' in df.columns:
                        st.subheader("🏙️ City Distribution")
                        city_data = df['city'].dropna()
                        city_data = city_data[city_data != '']
                        
                        if len(city_data) > 0:
                            city_counts = city_data.value_counts().head(20)
                            
                            col1, col2 = st.columns([2, 1])
                            
                            with col1:
                                fig_city = px.bar(
                                    x=city_counts.values,
                                    y=city_counts.index,
                                    orientation='h',
                                    title="📊 Top Cities by Provider Count",
                                    labels={'x': 'Number of Providers', 'y': 'City'},
                                    color=city_counts.values,
                                    color_continuous_scale="Viridis",
                                    text=city_counts.values
                                )
                                fig_city.update_traces(texttemplate='%{text}', textposition='outside')
                                fig_city.update_layout(yaxis={'categoryorder':'total ascending'}, showlegend=False, height=500)
                                st.plotly_chart(fig_city, use_container_width=True)
                            
                            with col2:
                                fig_city_pie = px.pie(
                                    values=city_counts.head(10).values,
                                    names=city_counts.head(10).index,
                                    title="🥧 Top 10 Cities",
                                    hole=0.4
                                )
                                st.plotly_chart(fig_city_pie, use_container_width=True)
                
                with viz_tab2:
                    # VALIDATION VISUALIZATIONS
                    st.subheader("✅ Validation Status Dashboard")
                    
                    if 'npi_validated' in df.columns and 'license_validated' in df.columns:
                        npi_validated = df['npi_validated'].fillna(False).astype(bool).sum()
                        license_validated = df['license_validated'].fillna(False).astype(bool).sum()
                        address_validated = df['address_validated'].fillna(False).astype(bool).sum() if 'address_validated' in df.columns else 0
                        total = len(df)
                        
                        validation_data = {
                            'NPI Validated': int(npi_validated),
                            'NPI Pending': int(total - npi_validated),
                            'License Validated': int(license_validated),
                            'License Pending': int(total - license_validated),
                            'Address Validated': int(address_validated),
                            'Address Pending': int(total - address_validated)
                        }
                        
                        if total > 0:
                            # Row 1: Comparison bar chart
                            st.markdown("### Comparison Chart")
                            validation_types = ['NPI', 'License', 'Address']
                            validated_counts = [validation_data['NPI Validated'], 
                                              validation_data['License Validated'],
                                              validation_data['Address Validated']]
                            pending_counts = [validation_data['NPI Pending'],
                                            validation_data['License Pending'],
                                            validation_data['Address Pending']]
                            
                            fig_validation_bar = go.Figure(data=[
                                go.Bar(name='✅ Validated', x=validation_types, y=validated_counts, marker_color='#4CAF50'),
                                go.Bar(name='⏳ Pending', x=validation_types, y=pending_counts, marker_color='#FF9800')
                            ])
                            fig_validation_bar.update_layout(
                                title='📊 Validation Status Comparison',
                                barmode='group',
                                yaxis_title='Number of Providers',
                                xaxis_title='Validation Type',
                                height=400
                            )
                            st.plotly_chart(fig_validation_bar, use_container_width=True)
                            
                            # Row 2: Pie charts
                            col1, col2, col3 = st.columns(3)
                            
                            with col1:
                                fig_npi = go.Figure(data=[go.Pie(
                                    labels=['✅ Validated', '⏳ Pending'],
                                    values=[validation_data['NPI Validated'], validation_data['NPI Pending']],
                                    marker_colors=['#4CAF50', '#FF9800'],
                                    hole=0.4
                                )])
                                fig_npi.update_layout(title="NPI Validation", height=300)
                                st.plotly_chart(fig_npi, use_container_width=True)
                            
                            with col2:
                                fig_license = go.Figure(data=[go.Pie(
                                    labels=['✅ Validated', '⏳ Pending'],
                                    values=[validation_data['License Validated'], validation_data['License Pending']],
                                    marker_colors=['#2196F3', '#FF5722'],
                                    hole=0.4
                                )])
                                fig_license.update_layout(title="License Validation", height=300)
                                st.plotly_chart(fig_license, use_container_width=True)
                            
                            with col3:
                                if 'address_validated' in df.columns:
                                    fig_address = go.Figure(data=[go.Pie(
                                        labels=['✅ Validated', '⏳ Pending'],
                                        values=[validation_data['Address Validated'], validation_data['Address Pending']],
                                        marker_colors=['#9C27B0', '#FFC107'],
                                        hole=0.4
                                    )])
                                    fig_address.update_layout(title="Address Validation", height=300)
                                    st.plotly_chart(fig_address, use_container_width=True)
                            
                            # Validation score distribution if available
                            if 'validation_score' in df.columns:
                                st.markdown("### Validation Score Distribution")
                                scores = df['validation_score'].dropna()
                                if len(scores) > 0:
                                    fig_score = px.histogram(
                                        scores,
                                        nbins=20,
                                        title="📊 Distribution of Validation Scores",
                                        labels={'value': 'Validation Score', 'count': 'Number of Providers'},
                                        color_discrete_sequence=['#673AB7']
                                    )
                                    fig_score.update_layout(showlegend=False, height=400)
                                    st.plotly_chart(fig_score, use_container_width=True)
                
                with viz_tab3:
                    # OVERVIEW VISUALIZATIONS
                    st.subheader("📊 Data Overview")
                    
                    # Enrichment status
                    if 'enriched_data' in df.columns:
                        st.markdown("### 🤖 AI Enrichment Status")
                        enriched_count = df['enriched_data'].notna().sum()
                        not_enriched = len(df) - enriched_count
                        
                        col1, col2 = st.columns([2, 1])
                        
                        with col1:
                            fig_enrichment = go.Figure(data=[go.Pie(
                                labels=['✅ Enriched', '❌ Not Enriched'],
                                values=[enriched_count, not_enriched],
                                marker_colors=['#00BCD4', '#FFC107'],
                                hole=0.4
                            )])
                            fig_enrichment.update_layout(
                                title="AI Enrichment Coverage",
                                annotations=[dict(text=f'{enriched_count}/{len(df)}<br>Enriched', x=0.5, y=0.5, font_size=16, showarrow=False)],
                                height=400
                            )
                            st.plotly_chart(fig_enrichment, use_container_width=True)
                        
                        with col2:
                            st.metric("Enrichment Rate", f"{(enriched_count/len(df)*100):.1f}%")
                            st.metric("Enriched", enriched_count)
                            st.metric("Not Enriched", not_enriched)
                    
                    # Data completeness
                    st.markdown("### 📈 Data Completeness")
                    completeness_data = {
                        'Field': ['Specialty', 'Facility', 'Services', 'Email', 'Phone', 'Address', 'City', 'State'],
                        'Complete': [
                            df['specialty'].notna().sum() if 'specialty' in df.columns else 0,
                            df['facility_name'].notna().sum() if 'facility_name' in df.columns else 0,
                            df['services_offered'].notna().sum() if 'services_offered' in df.columns else 0,
                            df['email'].notna().sum() if 'email' in df.columns else 0,
                            df['phone'].notna().sum() if 'phone' in df.columns else 0,
                            df['address'].notna().sum() if 'address' in df.columns else 0,
                            df['city'].notna().sum() if 'city' in df.columns else 0,
                            df['state'].notna().sum() if 'state' in df.columns else 0,
                        ],
                        'Total': [len(df)] * 8
                    }
                    completeness_df = pd.DataFrame(completeness_data)
                    completeness_df['Completeness %'] = (completeness_df['Complete'] / completeness_df['Total'] * 100).round(1)
                    
                    fig_completeness = px.bar(
                        completeness_df,
                        x='Field',
                        y='Completeness %',
                        title="📊 Data Completeness by Field",
                        color='Completeness %',
                        color_continuous_scale="RdYlGn",
                        text='Completeness %'
                    )
                    fig_completeness.update_traces(texttemplate='%{text:.1f}%', textposition='outside')
                    fig_completeness.update_layout(showlegend=False, yaxis_range=[0, 100], height=400)
                    st.plotly_chart(fig_completeness, use_container_width=True)
                
                with viz_tab4:
                    # DETAILED ANALYSIS
                    st.subheader("🔍 Detailed Analysis")
                    
                    # State vs Validation correlation
                    if 'state' in df.columns and 'license_validated' in df.columns:
                        st.markdown("### State vs Validation Status")
                        state_validation = df.groupby('state')['license_validated'].agg(['sum', 'count']).reset_index()
                        state_validation['validation_rate'] = (state_validation['sum'] / state_validation['count'] * 100).round(1)
                        state_validation = state_validation.sort_values('validation_rate', ascending=False)
                        
                        fig_state_val = px.bar(
                            state_validation,
                            x='state',
                            y='validation_rate',
                            title="📊 Validation Rate by State",
                            labels={'state': 'State', 'validation_rate': 'Validation Rate (%)'},
                            color='validation_rate',
                            color_continuous_scale="Greens",
                            text='validation_rate'
                        )
                        fig_state_val.update_traces(texttemplate='%{text:.1f}%', textposition='outside')
                        fig_state_val.update_layout(showlegend=False, height=400)
                        st.plotly_chart(fig_state_val, use_container_width=True)
                    
                    # Provider ID distribution (if sequential)
                    if 'provider_id' in df.columns:
                        st.markdown("### Provider Distribution")
                        # Extract numeric part if possible
                        try:
                            df['provider_num'] = df['provider_id'].str.extract('(\d+)')[0].astype(float)
                            fig_provider_dist = px.histogram(
                                df,
                                x='provider_num',
                                nbins=30,
                                title="📊 Provider ID Distribution",
                                labels={'provider_num': 'Provider Number', 'count': 'Frequency'},
                                color_discrete_sequence=['#E91E63']
                            )
                            fig_provider_dist.update_layout(showlegend=False, height=400)
                            st.plotly_chart(fig_provider_dist, use_container_width=True)
                        except:
                            pass
                
                # ========== QUICK VISUALIZATION SUMMARY ==========
                st.markdown("---")
                st.markdown("## 🎯 Quick Visualization Summary")
                
                # Create a grid of small visualizations
                summary_col1, summary_col2, summary_col3, summary_col4 = st.columns(4)
                
                with summary_col1:
                    # Total providers gauge
                    total = len(df)
                    fig_gauge = go.Figure(go.Indicator(
                        mode = "gauge+number",
                        value = total,
                        domain = {'x': [0, 1], 'y': [0, 1]},
                        title = {'text': "Total Providers"},
                        gauge = {
                            'axis': {'range': [None, total*1.2]},
                            'bar': {'color': "darkblue"},
                            'steps': [
                                {'range': [0, total*0.5], 'color': "lightgray"},
                                {'range': [total*0.5, total], 'color': "gray"}
                            ],
                            'threshold': {
                                'line': {'color': "red", 'width': 4},
                                'thickness': 0.75,
                                'value': total
                            }
                        }
                    ))
                    fig_gauge.update_layout(height=250)
                    st.plotly_chart(fig_gauge, use_container_width=True)
                
                with summary_col2:
                    # Validation rate
                    if 'license_validated' in df.columns:
                        validated = df['license_validated'].fillna(False).astype(bool).sum()
                        rate = (validated / total * 100) if total > 0 else 0
                        fig_val_gauge = go.Figure(go.Indicator(
                            mode = "gauge+number",
                            value = rate,
                            domain = {'x': [0, 1], 'y': [0, 1]},
                            title = {'text': "Validation Rate (%)"},
                            gauge = {
                                'axis': {'range': [None, 100]},
                                'bar': {'color': "green"},
                                'steps': [
                                    {'range': [0, 50], 'color': "lightgray"},
                                    {'range': [50, 100], 'color': "gray"}
                                ],
                                'threshold': {
                                    'line': {'color': "red", 'width': 4},
                                    'thickness': 0.75,
                                    'value': 90
                                }
                            }
                        ))
                        fig_val_gauge.update_layout(height=250)
                        st.plotly_chart(fig_val_gauge, use_container_width=True)
                
                with summary_col3:
                    # States count
                    if 'state' in df.columns:
                        state_count = df['state'].nunique()
                        fig_state_gauge = go.Figure(go.Indicator(
                            mode = "number+delta",
                            value = state_count,
                            domain = {'x': [0, 1], 'y': [0, 1]},
                            title = {'text': "Unique States"},
                            delta = {'reference': 10, 'position': "top"}
                        ))
                        fig_state_gauge.update_layout(height=250)
                        st.plotly_chart(fig_state_gauge, use_container_width=True)
                
                with summary_col4:
                    # Enrichment rate
                    if 'enriched_data' in df.columns:
                        enriched = df['enriched_data'].notna().sum()
                        rate = (enriched / total * 100) if total > 0 else 0
                        fig_enrich_gauge = go.Figure(go.Indicator(
                            mode = "gauge+number",
                            value = rate,
                            domain = {'x': [0, 1], 'y': [0, 1]},
                            title = {'text': "Enrichment Rate (%)"},
                            gauge = {
                                'axis': {'range': [None, 100]},
                                'bar': {'color': "purple"},
                                'steps': [
                                    {'range': [0, 50], 'color': "lightgray"},
                                    {'range': [50, 100], 'color': "gray"}
                                ]
                            }
                        ))
                        fig_enrich_gauge.update_layout(height=250)
                        st.plotly_chart(fig_enrich_gauge, use_container_width=True)
                
                # ========== ORIGINAL SECTIONS BELOW ==========
                st.markdown("---")
                st.markdown("## 📋 Additional Analytics")
                # Specialty Distribution
                st.subheader("🏥 Specialty Distribution")
                if 'specialty' in df.columns:
                    # Filter out null/empty values
                    specialty_data = df['specialty'].dropna()
                    specialty_data = specialty_data[specialty_data != '']
                    
                    if len(specialty_data) > 0:
                        specialty_counts = specialty_data.value_counts()

                        col1, col2 = st.columns([2, 1])

                        with col1:
                            fig = px.bar(specialty_counts.head(10),
                                       title="Top 10 Specialties",
                                       labels={'index': 'Specialty', 'value': 'Count'},
                                       color_discrete_sequence=['#1f77b4'])
                            st.plotly_chart(fig, use_container_width=True)

                        with col2:
                            fig_pie = px.pie(specialty_counts.head(5),
                                           names=specialty_counts.head(5).index,
                                           values=specialty_counts.head(5).values,
                                           title="Top 5 Specialties")
                            st.plotly_chart(fig_pie, use_container_width=True)
                    else:
                        st.info("No specialty data available for visualization")

                # Validation Status
                st.subheader("✅ Validation Overview")
                if 'npi_validated' in df.columns and 'license_validated' in df.columns:
                    # Convert boolean columns, handling None values
                    npi_validated = df['npi_validated'].fillna(False).astype(bool).sum()
                    license_validated = df['license_validated'].fillna(False).astype(bool).sum()
                    address_validated = df['address_validated'].fillna(False).astype(bool).sum() if 'address_validated' in df.columns else 0
                    total = len(df)
                    
                    validation_data = {
                        'NPI Validated': int(npi_validated),
                        'NPI Pending': int(total - npi_validated),
                        'License Validated': int(license_validated),
                        'License Pending': int(total - license_validated),
                        'Address Validated': int(address_validated),
                        'Address Pending': int(total - address_validated)
                    }

                    # Only show charts if we have data
                    if total > 0:
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            # Combined validation bar chart
                            validation_types = ['NPI', 'License', 'Address']
                            validated_counts = [validation_data['NPI Validated'], 
                                              validation_data['License Validated'],
                                              validation_data['Address Validated']]
                            pending_counts = [validation_data['NPI Pending'],
                                            validation_data['License Pending'],
                                            validation_data['Address Pending']]
                            
                            fig_validation_bar = go.Figure(data=[
                                go.Bar(name='Validated', x=validation_types, y=validated_counts, marker_color='#4CAF50'),
                                go.Bar(name='Pending', x=validation_types, y=pending_counts, marker_color='#FF9800')
                            ])
                            fig_validation_bar.update_layout(
                                title='Validation Status Comparison',
                                barmode='group',
                                yaxis_title='Number of Providers',
                                xaxis_title='Validation Type'
                            )
                            st.plotly_chart(fig_validation_bar, use_container_width=True)
                        
                        with col2:
                            # Pie charts for validation
                            fig = make_subplots(rows=1, cols=2, specs=[[{'type':'domain'}, {'type':'domain'}]],
                                              subplot_titles=('NPI Validation', 'License Validation'))

                            fig.add_trace(go.Pie(labels=['Validated', 'Pending'],
                                               values=[validation_data['NPI Validated'], validation_data['NPI Pending']],
                                               name="NPI Validation",
                                               marker_colors=['#4CAF50', '#FF9800']),
                                        1, 1)

                            fig.add_trace(go.Pie(labels=['Validated', 'Pending'],
                                               values=[validation_data['License Validated'], validation_data['License Pending']],
                                               name="License Validation",
                                               marker_colors=['#2196F3', '#FF5722']),
                                        1, 2)

                            fig.update_layout(title_text="Validation Status Overview", height=400)
                            st.plotly_chart(fig, use_container_width=True)
                        
                        # Address validation if available
                        if 'address_validated' in df.columns:
                            fig_address = go.Figure(data=[go.Pie(
                                labels=['Validated', 'Pending'],
                                values=[validation_data['Address Validated'], validation_data['Address Pending']],
                                marker_colors=['#9C27B0', '#FF5722'],
                                hole=0.4
                            )])
                            fig_address.update_layout(title="Address Validation Status", height=300)
                            st.plotly_chart(fig_address, use_container_width=True)
                    else:
                        st.info("No validation data available")

                # Geographic Distribution
                st.subheader("🌍 Geographic Distribution")
                if 'state' in df.columns:
                    # Filter out null/empty values
                    state_data = df['state'].dropna()
                    state_data = state_data[state_data != '']
                    
                    if len(state_data) > 0:
                        state_counts = state_data.value_counts()

                        if len(state_counts) > 0:
                            col1, col2 = st.columns([2, 1])
                            
                            with col1:
                                # Bar chart for state distribution
                                fig_state_bar = px.bar(
                                    x=state_counts.index,
                                    y=state_counts.values,
                                    title="Providers by State",
                                    labels={'x': 'State', 'y': 'Number of Providers'},
                                    color=state_counts.values,
                                    color_continuous_scale="Blues"
                                )
                                fig_state_bar.update_layout(showlegend=False)
                                st.plotly_chart(fig_state_bar, use_container_width=True)
                            
                            with col2:
                                # Pie chart for top states
                                top_states = state_counts.head(10)
                                fig_state_pie = px.pie(
                                    values=top_states.values,
                                    names=top_states.index,
                                    title="Top 10 States Distribution"
                                )
                                st.plotly_chart(fig_state_pie, use_container_width=True)
                            
                            # Choropleth map
                            try:
                                fig_map = px.choropleth(
                                    locations=state_counts.index,
                                    locationmode="USA-states",
                                    color=state_counts.values,
                                    scope="usa",
                                    title="Geographic Distribution Map",
                                    color_continuous_scale="Blues",
                                    labels={'color': 'Providers'}
                                )
                                st.plotly_chart(fig_map, use_container_width=True)
                            except Exception as e:
                                st.info(f"Map visualization unavailable: {e}")
                        else:
                            st.info("No state data available")
                    else:
                        st.info("No state data available for visualization")
                
                # City Distribution
                st.subheader("🏙️ City Distribution")
                if 'city' in df.columns:
                    city_data = df['city'].dropna()
                    city_data = city_data[city_data != '']
                    
                    if len(city_data) > 0:
                        city_counts = city_data.value_counts().head(15)
                        
                        if len(city_counts) > 0:
                            fig_city = px.bar(
                                x=city_counts.values,
                                y=city_counts.index,
                                orientation='h',
                                title="Top 15 Cities by Provider Count",
                                labels={'x': 'Number of Providers', 'y': 'City'},
                                color=city_counts.values,
                                color_continuous_scale="Viridis"
                            )
                            fig_city.update_layout(yaxis={'categoryorder':'total ascending'}, showlegend=False)
                            st.plotly_chart(fig_city, use_container_width=True)
                        else:
                            st.info("No city data available")
                    else:
                        st.info("No city data available for visualization")

                # Facility Types
                st.subheader("🏢 Facility Distribution")
                if 'facility_name' in df.columns:
                    # Filter out null/empty values
                    facility_data = df['facility_name'].dropna()
                    facility_data = facility_data[facility_data != '']
                    
                    if len(facility_data) > 0:
                        facility_counts = facility_data.value_counts().head(10)

                        if len(facility_counts) > 0:
                            fig_facility = px.bar(facility_counts,
                                                title="Top Healthcare Facilities",
                                                orientation='h',
                                                color_discrete_sequence=['#8BC34A'])
                            fig_facility.update_layout(yaxis={'categoryorder':'total ascending'})
                            st.plotly_chart(fig_facility, use_container_width=True)
                        else:
                            st.info("No facility data available")
                    else:
                        st.info("No facility data available for visualization")

                # Services Offered
                st.subheader("🩺 Services Analysis")
                if 'services_offered' in df.columns:
                    # Simple word cloud simulation with bar chart
                    all_services = []
                    for services in df['services_offered'].dropna():
                        if services and str(services).strip():
                            # Handle both string and list-like formats
                            if isinstance(services, str):
                                all_services.extend([s.strip() for s in str(services).split(',') if s.strip()])
                            else:
                                all_services.append(str(services).strip())

                    if len(all_services) > 0:
                        service_counts = pd.Series(all_services).value_counts().head(15)
                        
                        if len(service_counts) > 0:
                            fig_services = px.bar(service_counts,
                                                title="Most Common Services Offered",
                                                color_discrete_sequence=['#9C27B0'])
                            st.plotly_chart(fig_services, use_container_width=True)
                        else:
                            st.info("No services data available")
                    else:
                        st.info("No services data available for visualization")
                
                # Enrichment Status
                st.subheader("🤖 AI Enrichment Status")
                if 'enriched_data' in df.columns:
                    enriched_count = df['enriched_data'].notna().sum()
                    not_enriched = len(df) - enriched_count
                    
                    fig_enrichment = go.Figure(data=[go.Pie(
                        labels=['Enriched', 'Not Enriched'],
                        values=[enriched_count, not_enriched],
                        marker_colors=['#00BCD4', '#FFC107'],
                        hole=0.3
                    )])
                    fig_enrichment.update_layout(
                        title="AI Enrichment Coverage",
                        annotations=[dict(text=f'{enriched_count}/{len(df)}', x=0.5, y=0.5, font_size=20, showarrow=False)]
                    )
                    st.plotly_chart(fig_enrichment, use_container_width=True)
                
                # Validation Score Distribution
                if 'validation_score' in df.columns:
                    st.subheader("📊 Validation Score Distribution")
                    scores = df['validation_score'].dropna()
                    if len(scores) > 0:
                        fig_score = px.histogram(
                            scores,
                            nbins=20,
                            title="Distribution of Validation Scores",
                            labels={'value': 'Validation Score', 'count': 'Number of Providers'},
                            color_discrete_sequence=['#673AB7']
                        )
                        fig_score.update_layout(showlegend=False)
                        st.plotly_chart(fig_score, use_container_width=True)
                
                # Add a summary section showing data availability
                st.markdown("---")
                st.subheader("📈 Data Summary Dashboard")
                
                # Create metrics in a grid
                col1, col2, col3, col4, col5 = st.columns(5)
                with col1:
                    st.metric("Total Providers", len(df))
                with col2:
                    non_null_specialty = df['specialty'].notna().sum() if 'specialty' in df.columns else 0
                    st.metric("With Specialty", non_null_specialty, delta=f"{non_null_specialty/len(df)*100:.1f}%")
                with col3:
                    non_null_facility = df['facility_name'].notna().sum() if 'facility_name' in df.columns else 0
                    st.metric("With Facility", non_null_facility, delta=f"{non_null_facility/len(df)*100:.1f}%")
                with col4:
                    non_null_services = df['services_offered'].notna().sum() if 'services_offered' in df.columns else 0
                    st.metric("With Services", non_null_services, delta=f"{non_null_services/len(df)*100:.1f}%")
                with col5:
                    enriched_count = df['enriched_data'].notna().sum() if 'enriched_data' in df.columns else 0
                    st.metric("AI Enriched", enriched_count, delta=f"{enriched_count/len(df)*100:.1f}%")
                
                # Data completeness visualization
                st.markdown("### Data Completeness Heatmap")
                completeness_data = {
                    'Field': ['Specialty', 'Facility Name', 'Services', 'Email', 'Phone', 'Address', 'City', 'State'],
                    'Completeness %': [
                        (df['specialty'].notna().sum() / len(df) * 100) if 'specialty' in df.columns else 0,
                        (df['facility_name'].notna().sum() / len(df) * 100) if 'facility_name' in df.columns else 0,
                        (df['services_offered'].notna().sum() / len(df) * 100) if 'services_offered' in df.columns else 0,
                        (df['email'].notna().sum() / len(df) * 100) if 'email' in df.columns else 0,
                        (df['phone'].notna().sum() / len(df) * 100) if 'phone' in df.columns else 0,
                        (df['address'].notna().sum() / len(df) * 100) if 'address' in df.columns else 0,
                        (df['city'].notna().sum() / len(df) * 100) if 'city' in df.columns else 0,
                        (df['state'].notna().sum() / len(df) * 100) if 'state' in df.columns else 0,
                    ]
                }
                completeness_df = pd.DataFrame(completeness_data)
                fig_completeness = px.bar(
                    completeness_df,
                    x='Field',
                    y='Completeness %',
                    title="Data Completeness by Field",
                    color='Completeness %',
                    color_continuous_scale="RdYlGn",
                    text='Completeness %'
                )
                fig_completeness.update_traces(texttemplate='%{text:.1f}%', textposition='outside')
                fig_completeness.update_layout(showlegend=False, yaxis_range=[0, 100])
                st.plotly_chart(fig_completeness, use_container_width=True)

            else:
                st.info("No data available for analytics. Please upload provider data first.")
        else:
            st.error("Failed to fetch analytics data. Is the API running?")
    except Exception as e:
        st.error(f"Analytics error: {e}")

elif page == "AI Processing":
    st.header("🤖 AI Processing Center")

    st.markdown("### AI Agent Status")
    col1, col2, col3 = st.columns(3)

    with col1:
        st.metric("Validation Agent", "🟢 Active")
        st.caption("Validates NPI, licenses, and addresses")

    with col2:
        st.metric("Enrichment Agent", "🟢 Active")
        st.caption("Enhances provider data with AI insights")

    with col3:
        st.metric("Crew Manager", "🟢 Active")
        st.caption("Orchestrates multi-agent workflows")

    st.markdown("---")

    # Manual AI Processing
    st.subheader("Manual AI Processing")

    provider_id = st.text_input("Enter Provider ID for AI processing", placeholder="e.g., P001")

    col1, col2 = st.columns(2)

    with col1:
        if st.button("🔍 Validate Provider", type="primary"):
            if provider_id:
                with st.spinner("Running AI validation..."):
                    result = api_request("post", f"validate-provider/{provider_id}")
                    if result:
                        st.success("✅ Validation completed!")
                        # Display results
                        st.json(result)
                    else:
                        st.error("❌ Validation failed. Is the API running?")
            else:
                st.warning("Please enter a Provider ID")


    with col2:
        if st.button("🧠 Enrich Provider", type="primary"):
            if provider_id:
                with st.spinner("Running AI enrichment..."):
                    result = api_request("post", f"enrich-provider/{provider_id}")
                    if result:
                        st.success("✅ Enrichment completed!")
                        # Display results
                        st.json(result)
                    else:
                        st.error("❌ Enrichment failed. Is the API running?")
            else:
                st.warning("Please enter a Provider ID")

    # Batch and QA Actions
    st.markdown("---")
    st.subheader("Batch & QA Actions")
    bcol1, bcol2 = st.columns(2)
    with bcol1:
        if st.button("🚀 Run Batch Validate (All)"):
            with st.spinner("Running batch validation..."):
                res = api_request("post", "batch-validate")
                if res:
                    st.success("Batch validation finished")
                    st.json(res)
                else:
                    st.error("Batch validation failed or API offline")
    with bcol2:
        if st.button("🧾 Generate QA Report"):
            with st.spinner("Generating QA report..."):
                res = api_request("post", "qa/report")
                if res:
                    st.success(f"QA report generated: {res.get('count',0)} items")
                    try:
                        download_payload = json.dumps(res, default=str)
                        st.download_button("Download QA Report (JSON)", data=download_payload, file_name="qa_report.json", mime="application/json")
                    except Exception:
                        pass
                    st.json(res)
                else:
                    st.error("QA report failed or API offline")

    # Processing History
    st.markdown("---")
    st.subheader("Recent AI Processing History")

    history = api_request("get", "processing-history", params={"limit": 10})
    if history:
        for item in history:
            status_icon = "✅" if item.get('status') == 'success' else "❌"
            timestamp = item.get('timestamp', 'N/A')
            st.write(f"{status_icon} {timestamp} - {item.get('provider_id')} - {item.get('operation')}")
    elif history == []:
        st.info("No recent processing history")
    else:
        st.info("Processing history unavailable")

# Footer
st.markdown("---")
st.markdown("Built with ❤️ using CrewAI, LangChain, and Streamlit | Healthcare Provider AI System v1.0")
