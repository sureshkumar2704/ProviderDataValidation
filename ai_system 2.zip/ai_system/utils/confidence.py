import math


def calculate_confidence(local_value, external_value, source_weight=1.0) -> float:
    """Simple confidence scoring:
    - Exact match -> weight * 1.0
    - Partial match (substring) -> weight * 0.6
    - Different or missing -> weight * 0.0
    Returns a score between 0.0 and 1.0
    """
    if external_value is None:
        return 0.0
    try:
        lv = str(local_value).strip().lower() if local_value is not None else ""
        ev = str(external_value).strip().lower()
        if not ev:
            return 0.0
        if lv == ev:
            return min(1.0, source_weight)
        if lv and lv in ev or ev in lv:
            return min(1.0, 0.6 * source_weight)
        return 0.0
    except Exception:
        return 0.0


def aggregate_confidences(scores: list) -> float:
    """Aggregate multiple source scores into a single confidence (simple max-weighted).
    Uses root-mean-square style aggregation to reward multiple agreeing sources.
    """
    if not scores:
        return 0.0
    # clamp
    scores = [min(1.0, max(0.0, float(s))) for s in scores]
    # RMS
    sq = sum(s * s for s in scores)
    return math.sqrt(sq / len(scores))


def flag_discrepancies(local_data: dict, external_data: dict) -> dict:
    """Return dict of fields where local != external (simple equality check)."""
    flags = {}
    for k, lv in local_data.items():
        ev = external_data.get(k)
        if ev is None:
            continue
        if str(lv).strip().lower() != str(ev).strip().lower():
            flags[k] = {"local": lv, "external": ev}
    return flags
