import pandas as pd
from typing import List, Dict, Union, IO

def load_provider_data(csv_path: Union[str, IO, bytes]) -> List[Dict]:
    """
    Load provider data from a file path or file-like object (Streamlit UploadedFile).
    Returns list of dicts (rows). Returns empty list when CSV has no rows.
    """
    try:
        # pandas can handle file paths, URLs, and file-like objects directly.
        # For file-like objects from Streamlit, we should ensure the pointer is at the start.
        if hasattr(csv_path, "seek"):
            csv_path.seek(0)
        df: pd.DataFrame = pd.read_csv(csv_path)
    except pd.errors.EmptyDataError:
        return []
    except Exception:
        raise

    column_mapping = {
        'provider_id': 'provider_id',
        'first_name': 'first_name',
        'last_name': 'last_name',
        'phone': 'phone',
        'email': 'email',
        'specialty': 'specialty',
        'license_no': 'license_no',
        'certifications': 'certifications',
        'insurance_networks': 'insurance_networks',
        'affiliations': 'affiliations',
        'services_offered': 'services_offered',
        'appointment_availability': 'appointment_availability',
        'address': 'address',
        'city': 'city',
        'state': 'state',
        'zip': 'zip_code',
        'facility_name': 'facility_name',
        'imaging_available': 'imaging_available',
        'website_url': 'website_url'
    }

    existing_cols = {k: v for k, v in column_mapping.items() if k in df.columns}
    df = df.rename(columns=existing_cols)

    if 'imaging_available' in df.columns:
        # Make mapping case-insensitive and more robust
        bool_map = {'yes': True, 'true': True, 't': True, '1': True,
                    'no': False, 'false': False, 'f': False, '0': False}
        df['imaging_available'] = df['imaging_available'].astype(str).str.lower().map(bool_map)

    return df.to_dict('records')