import requests
import logging

logger = logging.getLogger(__name__)


def validate_npi_via_api(npi_number: str, timeout: int = 10) -> dict:
    """Validate NPI using the CMS NPI Registry API.

    Returns a dict with keys: 'valid' (bool), 'details' (dict|None), and optionally 'error'.
    """
    url = f"https://npiregistry.cms.hhs.gov/api/?number={npi_number}&version=2.1"
    try:
        resp = requests.get(url, timeout=timeout)
        resp.raise_for_status()
        data = resp.json()
        if data.get("results"):
            return {"valid": True, "details": data["results"][0]}
        return {"valid": False, "details": None}
    except Exception as e:
        logger.exception("Error validating NPI via API")
        return {"valid": False, "details": None, "error": str(e)}
