import requests
import logging

logger = logging.getLogger(__name__)


def validate_address_via_google(address: str, api_key: str, timeout: int = 8) -> dict:
    """Validate address using Google Geocoding API.

    Returns dict with keys: valid (bool), formatted_address, latitude, longitude, raw (full response)
    """
    if not api_key:
        return {"valid": False, "error": "No API key provided"}

    url = "https://maps.googleapis.com/maps/api/geocode/json"
    try:
        params = {"address": address, "key": api_key}
        r = requests.get(url, params=params, timeout=timeout)
        r.raise_for_status()
        data = r.json()
        if data.get("status") == "OK" and data.get("results"):
            res = data["results"][0]
            loc = res["geometry"]["location"]
            return {
                "valid": True,
                "formatted_address": res.get("formatted_address"),
                "latitude": loc.get("lat"),
                "longitude": loc.get("lng"),
                "raw": res,
            }
        return {"valid": False, "raw": data}
    except Exception as e:
        logger.exception("Google Maps validation error")
        return {"valid": False, "error": str(e)}
