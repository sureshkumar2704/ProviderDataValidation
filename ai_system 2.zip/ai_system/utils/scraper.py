import requests
from bs4 import BeautifulSoup
import re
import logging

logger = logging.getLogger(__name__)


def fetch_html(url: str, timeout: int = 8) -> str:
    try:
        headers = {"User-Agent": "Mozilla/5.0 (compatible; DataValidator/1.0)"}
        r = requests.get(url, headers=headers, timeout=timeout)
        r.raise_for_status()
        return r.text
    except Exception as e:
        logger.debug(f"fetch_html error for {url}: {e}")
        return ""


def extract_contact_info(html: str) -> dict:
    """Extract basic contact info (phone, email, address) from HTML.

    Returns a dict with keys: phone, emails (list), addresses (list)
    """
    soup = BeautifulSoup(html, "lxml")
    text = soup.get_text(separator=' ', strip=True)

    # phone regex (simple)
    phone_rx = re.compile(r"\+?\d[\d\s\-()]{6,}\d")
    phones = list({m.group(0).strip() for m in phone_rx.finditer(text)})

    # simple email extraction
    emails = list({a.get('href').split(':', 1)[1] for a in soup.select('a[href^="mailto:"]')})
    if not emails:
        emails = list({m.group(0) for m in re.finditer(r"[\w\.-]+@[\w\.-]+", text)})

    # address heuristics: look for <address> tags or common address patterns
    addresses = []
    addr_tags = soup.find_all('address')
    for tag in addr_tags:
        addresses.append(tag.get_text(' ', strip=True))

    if not addresses:
        # heuristic: look for lines with numbers + street words
        lines = [l.strip() for l in text.split('\n') if l.strip()]
        for line in lines:
            if re.search(r"\d+\s+\w+\s+(Street|St|Road|Rd|Ave|Avenue|Blvd|Suite|Ste|Court|Ct)", line, re.I):
                addresses.append(line)
                if len(addresses) >= 3:
                    break

    return {
        "phones": phones,
        "emails": emails,
        "addresses": addresses,
    }


def scrape_website_for_provider(url: str) -> dict:
    """High-level helper: fetch HTML and extract contact info."""
    html = fetch_html(url)
    if not html:
        return {"phones": [], "emails": [], "addresses": []}
    return extract_contact_info(html)
